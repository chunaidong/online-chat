package com.wangmike.chat.service;

public interface HelloService {

    public String sayHello();

}
