package com.wangmike.chat.common.entity;


/**
 * 常量通用类
 */
public abstract class CommanContranst {

     //成功编号
     public static final String SUCCESS_CODE="10000";
     //成功信息
     public static final String SUCCESS_MSG="访问成功";

     //失败编号
     public static final String ERROR_CODE="10001";

}
